'use strict';

var $ = function (id) { return document.getElementById(id); };
var CLASSROOMS_URL = 'https://schools.madrasati.sa/SchoolStructure/ClassRooms';
var DAY_NAMES = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];
var now = new Date();
var TODAY = ymd(now);

function ymd(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function weekDates(offset) {
  var s = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay() + offset * 7);
  return DAY_NAMES.map(function (n, i) {
    var d = new Date(s.getFullYear(), s.getMonth(), s.getDate() + i);
    return { name: n, date: ymd(d), label: d.getDate() + '/' + (d.getMonth() + 1), future: ymd(d) > TODAY };
  });
}

/* ---------- الإعدادات (قائمة الغياب تُمسح كل يوم) ---------- */
function load(cb) {
  chrome.storage.local.get(['mode', 'namesDay', 'names'], function (r) {
    cb({ mode: r.mode === 'abs' ? 'abs' : 'all', names: r.namesDay === TODAY ? (r.names || '') : '' });
  });
}
function save() { chrome.storage.local.set({ mode: mode(), names: $('names').value, namesDay: TODAY }); }
function mode() { var r = document.querySelector('input[name=mode]:checked'); return r ? r.value : 'all'; }
function paint() {
  var m = mode();
  $('optAll').classList.toggle('on', m === 'all');
  $('optAbs').classList.toggle('on', m === 'abs');
  $('absBox').style.display = m === 'abs' ? 'block' : 'none';
}
function status(msg, cls) { var s = $('status'); s.textContent = msg; s.className = cls || ''; }
function busy(b) { $('quick').disabled = b; $('open').disabled = b; }
function namesList() {
  return $('names').value.split(/\n|،|,/).map(function (x) { return x.trim(); }).filter(function (x) { return x.length > 1; });
}

/* ---------- اختيار الأيام ---------- */
var selected = {};
function renderDays() {
  var list = weekDates(parseInt($('week').value, 10));
  $('days').innerHTML = '';
  list.forEach(function (d) {
    var el = document.createElement('label');
    el.className = 'day' + (d.future ? ' dis' : '') + (selected[d.date] ? ' on' : '');
    el.innerHTML = '<span>' + d.name + '</span><small>' + d.label + '</small>';
    el.title = d.future ? 'يوم لم يأتِ بعد' : d.date;
    if (!d.future) el.onclick = function () { selected[d.date] = !selected[d.date]; renderDays(); };
    $('days').appendChild(el);
  });
}
function pick(fn) {
  selected = {};
  weekDates(parseInt($('week').value, 10)).forEach(function (d) { if (!d.future && fn(d)) selected[d.date] = true; });
  renderDays();
}
function chosenDates() {
  return weekDates(parseInt($('week').value, 10))
    .filter(function (d) { return selected[d.date] && !d.future; })
    .map(function (d) { return { date: d.date, name: d.name + ' ' + d.label }; });
}

/* ---------- التعامل مع التبويب ---------- */
function activeTab() {
  return new Promise(function (res, rej) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var t = tabs && tabs[0];
      if (!t || !/^https:\/\/schools\.madrasati\.sa\//.test(t.url || '')) rej(new Error('notMadrasati'));
      else res(t);
    });
  });
}
function ensureClassroomsPage(tab) {
  if (/\/schoolstructure\/classrooms/i.test(tab.url || '')) return Promise.resolve(tab);
  status('جاري فتح صفحة الفصول…');
  return new Promise(function (res) {
    chrome.tabs.update(tab.id, { url: CLASSROOMS_URL }, function () {
      function done(id, info, t) {
        if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(done); setTimeout(function () { res(t); }, 800); }
      }
      chrome.tabs.onUpdated.addListener(done);
    });
  });
}
function run(tabId, opts) {
  return chrome.scripting.executeScript(Object.assign({ target: { tabId: tabId }, world: 'MAIN' }, opts))
    .then(function (r) { return r && r[0] ? r[0].result : undefined; });
}

/* ---------- دوال تُنفَّذ داخل الصفحة ---------- */
function pageSetCfg(cfg) { window.__smAbsCfg = cfg; return true; }
function pageToolState() {
  var m = document.getElementById('sm-madrasati-tracker-modal');
  if (m) { m.style.display = 'flex'; return 'exists'; }
  return 'need';
}
function pageAbsReport() {
  var a = window.__smAbsExt;
  return a ? { matched: a.report.matched, periods: a.report.periods, noAbs: a.report.noAbsentOption } : null;
}
function pageSchool() {
  var q = new URLSearchParams(location.search);
  var id = q.get('schoolId') || q.get('SchoolId') || (document.getElementById('hSchoolId') || {}).value ||
    (document.querySelector('input[name="SchoolId"]') || {}).value || localStorage.getItem('madrasati_hSchoolId') || localStorage.getItem('globalschoolId') || '';
  var el = document.querySelector('.school-name, .user-school-name, #schoolName, .navbar-brand span');
  var nm = (el && el.textContent.trim()) || localStorage.getItem('school_name_' + id) || localStorage.getItem('madrasati_schoolName') || '';
  return { id: String(id || ''), name: nm };
}

/* ---------- المدارس المحفوظة ---------- */
var schoolList = [], currentId = '';
function renderSchools() {
  var box = $('schools');
  if (!schoolList.length) return;
  box.innerHTML = '';
  schoolList.forEach(function (sc, i) {
    var row = document.createElement('label'); row.className = 'sc';
    row.innerHTML = '<input type="checkbox"' + (sc.on ? ' checked' : '') + '><span>' + sc.name.replace(/</g, '&lt;') + '</span>' +
      (sc.id === currentId ? '<small>(الحالية)</small>' : '') + '<span class="del" title="حذف من القائمة">×</span>';
    row.querySelector('input').onchange = function (e) { sc.on = e.target.checked; saveSchools(); };
    row.querySelector('.del').onclick = function (e) { e.preventDefault(); schoolList.splice(i, 1); saveSchools(); renderSchools(); };
    box.appendChild(row);
  });
}
function saveSchools() { chrome.storage.local.set({ schools: schoolList }); }
function chosenSchools() { return schoolList.filter(function (s) { return s.on; }).map(function (s) { return { id: s.id, name: s.name }; }); }
function loadSchools() {
  chrome.storage.local.get(['schools', 'speed'], async function (r) {
    schoolList = Array.isArray(r.schools) ? r.schools : [];
    if (r.speed) $('speed').value = r.speed;
    try {
      var tab = await activeTab();
      var cur = await run(tab.id, { func: pageSchool });
      if (cur && cur.id) {
        currentId = cur.id;
        var ex = schoolList.find(function (s) { return s.id === cur.id; });
        if (ex) { if (cur.name) ex.name = cur.name; }
        else { schoolList.forEach(function (s) { s.on = false; }); schoolList.push({ id: cur.id, name: cur.name || ('مدرسة ' + cur.id), on: true }); }
        saveSchools();
      }
    } catch (e) {}
    renderSchools();
  });
}

/* ---------- التشغيل ---------- */
async function prepare(m, names) {
  var tab = await activeTab();
  tab = await ensureClassroomsPage(tab);
  status('جاري التجهيز…');
  await run(tab.id, { func: pageSetCfg, args: [{ mode: m, names: names }] });
  await run(tab.id, { files: ['page_addon.js'] });
  var state = await run(tab.id, { func: pageToolState });
  if (state === 'need') await run(tab.id, { files: ['attendance_tracker.js'] });
  return tab;
}

async function start(quick) {
  save();
  var m = mode(), names = namesList();
  if (m === 'abs' && !names.length) { status('اكتب أسماء الغائبين، أو اختر «جميع الطلاب حاضرون».', 'err'); return; }
  busy(true);
  try {
    if (!quick) {
      await prepare(m, names);
      status('تم فتح اللوحة التفصيلية في الصفحة.', 'ok'); window.close(); return;
    }
    var days = chosenDates();
    if (!days.length) { status('اختر يوماً واحداً على الأقل.', 'err'); return; }
    var schools = chosenSchools();
    if (!schools.length) { status('اختر مدرسة واحدة على الأقل.', 'err'); return; }
    var tab = await activeTab();
    tab = await ensureClassroomsPage(tab);
    var cur = await run(tab.id, { func: pageSchool });
    await run(tab.id, { files: ['engine.js'] });
    await run(tab.id, {
      func: function (cfg) { return window.__smEngine.open(cfg); },
      args: [{ mode: m, names: names, dates: days.map(function (d) { return d.date; }), schools: schools,
               currentSchoolId: cur && cur.id, concurrency: parseInt($('speed').value, 10) }]
    });
    chrome.storage.local.set({ speed: $('speed').value });
    window.close();
  } catch (e) {
    if (e && e.message === 'notMadrasati') status('افتح منصة مدرستي (schools.madrasati.sa) بحساب المدير أولاً، ثم اضغط الزر.', 'err');
    else status('حدث خطأ: ' + (e && e.message || e), 'err');
  } finally { busy(false); }
}

async function showReport() {
  try {
    var tab = await activeTab();
    var r = await run(tab.id, { func: pageAbsReport });
    if (!r) { alert('لم يُنفَّذ رصد بالغياب في هذه الصفحة بعد.'); return; }
    var norm = function (s) {
      return s.replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/\s+/g, ' ').trim();
    };
    var lines = namesList().map(function (n) {
      var c = r.matched[norm(n)];
      return c ? '✅ ' + n + ' — غائب في ' + c + ' حصة' : '❌ ' + n + ' — لم يُعثر عليه';
    });
    var msg = 'حصص حُفظت: ' + r.periods + '\n\n' + lines.join('\n');
    if (r.noAbs) msg += '\n\n⚠️ تعذّر تحديد خيار «غائب» في ' + r.noAbs + ' حالة — راجعها يدوياً.';
    alert(msg);
  } catch (e) { alert('افتح صفحة منصة مدرستي أولاً.'); }
}

/* ---------- ربط الواجهة ---------- */
load(function (s) {
  document.querySelector('input[name=mode][value="' + s.mode + '"]').checked = true;
  $('names').value = s.names;
  paint();
});
selected[TODAY] = true;
renderDays();
$('week').onchange = function () { selected = {}; renderDays(); };
$('pickToday').onclick = function (e) { e.preventDefault(); $('week').value = '0'; pick(function (d) { return d.date === TODAY; }); };
$('pickAll').onclick = function (e) { e.preventDefault(); pick(function () { return true; }); };
$('pickNone').onclick = function (e) { e.preventDefault(); pick(function () { return false; }); };
document.querySelectorAll('input[name=mode]').forEach(function (r) { r.onchange = function () { paint(); save(); }; });
$('names').oninput = save;
$('quick').onclick = function () { start(true); };
$('open').onclick = function () { start(false); };
loadSchools();
